#ifndef QUERY_PLAY_UI_H
#define QUERY_PLAY_UI_H

#include "../Service/Play.h"

void DisplayQueryPlay(void);

#endif
