#ifndef QUERIES_MENU_H_
#define QUERIES_MENU_H_
#include "../Common/list.h"
#include "../Service/Play.h"

void Queries_Menu(void);


#endif /* QUERIES_MENU_H_ */
