package xupt.se.ttms.view.UI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.File;
import java.util.Random;
import javax.swing.*;
 
public class Choose {
	public static void main(String[] args){
			
	}
}
