package xupt.se.ttms.view.sched;

public class SchedSelUI {

}
