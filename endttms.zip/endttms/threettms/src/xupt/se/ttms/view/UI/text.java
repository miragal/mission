package xupt.se.ttms.view.UI;
import java.awt.*;
import javax.swing.*;
public class text extends JFrame{
	public static void main(String[] args){
		text frame=new text();
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("demo");
		frame.setVisible(true);
	}
	
	
}
