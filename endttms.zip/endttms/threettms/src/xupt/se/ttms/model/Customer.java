﻿package xupt.se.ttms.model;

public class Customer {
	
	private int customer_id;
	private String customer_name;
	private String customer_sex;
	private int customer_bill;
	private String customer_tel;
	private String customer_descp;
	
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_sex() {
		return customer_sex;
	}
	public void setCustomer_sex(String customer_sex) {
		this.customer_sex = customer_sex;
	}
	public int getCustomer_bill() {
		return customer_bill;
	}
	public void setCustomer_bill(int customer_bill) {
		this.customer_bill = customer_bill;
	}
	public String getCustomer_tel() {
		return customer_tel;
	}
	public void setCustomer_tel(String customer_tel) {
		this.customer_tel = customer_tel;
	}
	public String getCustomer_descp() {
		return customer_descp;
	}
	public void setCustomer_descp(String customer_descp) {
		this.customer_descp = customer_descp;
	}
	
	
}
