package xupt.se.ttms.model;

public class User {
	protected int userID;
	protected int empID;
	//other infor

}
