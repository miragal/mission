package xupt.se.ttms.model;

public class Sign_in {
	private String name;
	private String pass;
	public void setname(String name){
		this.name=name;
		
	}
	public void setpass(String pass){
		this.pass=pass;
	}
	public String getname(){
		return name;
		
	}
	public String getpass(){
		return pass;
	}
}
