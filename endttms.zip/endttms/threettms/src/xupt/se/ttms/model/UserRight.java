package xupt.se.ttms.model;

public class UserRight {

}
